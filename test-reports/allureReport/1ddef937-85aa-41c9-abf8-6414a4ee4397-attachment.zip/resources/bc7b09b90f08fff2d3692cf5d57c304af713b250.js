window.addEventListener("load", function(event) {
  Sifi.modules.common = function(sifi) {
    function Common(sifi) {
      var self = {};

      var call = function(ad, sifiFeedInfo, adSize) {
        var feed_items = [];
        var productIndex = 0;
        var currentProduct = null;

        var targets = document.getElementsByClassName("clickable");
        Array.prototype.forEach.call(targets, function(target) {
          target.addEventListener("click", function(event) {
            ad.clickThru(currentProduct);
          });
        });

        function initializeUi() {
          function animateOut(element, distance, direction) {
            var p = 0;
            var id = setInterval(move, 1);
            function move() {
              offset = (direction == "right") ? 0 - distance : distance;
              if (p == offset) {
                clearInterval(id);
              } else {
                if (direction == "right") {
                  p -= 5;
                } else {
                  p += 5;
                }
                element.style.left = p + 'px';
              }
            }
          }

          function animateIn(element, distance, direction) {
            var p = (direction == "right") ? distance : 0 - distance;
            var id = setInterval(move, 1);
            function move() {
              if(p == 0) {
                clearInterval(id);
              } else {
                if (direction == "right") {
                  p -= 5;
                } else {
                  p += 5;
                }
                element.style.left = p + 'px';
              }
            }
          }

          var btnLeft = document.getElementById('arrow-left');
          var btnRight = document.getElementById('arrow-right');

          var ScrollNav = {
            left: function(event) {
              event.stopPropagation();
              sifi.shared.decrementProductIndex(productIndex, ad, feed_items, indexChanged);
              ScrollNav.transition("left");
            },
            right: function(event) {
              event.stopPropagation();
              sifi.shared.incrementProductIndex(productIndex, ad, feed_items, indexChanged);
              ScrollNav.transition("right");
            },
            transition: function(direction) {
              var ad_width = 0;
              if(adSize === 300600) { ad_width = 300; }
              if(adSize === 300250) { ad_width = 300; }
              if(adSize === 72890) { ad_width = 355; }
              if(adSize === 160600) { ad_width = 160; }
              if(adSize === 32050) { ad_width = 230; }
              if(adSize === 30050) { ad_width = 230; }

              current_ad = document.getElementById('current-ad');
              animateOut(current_ad, ad_width, direction);

              var replica = current_ad.cloneNode(true);
              document.getElementById('item-price-s').id = "";
              document.getElementById('item-price').id = "";
              document.getElementById('item-subtitle').id = "";
              document.getElementById('item-title').id = "";
              current_ad.id = "";
              replica.style.left = "-" + ad_width + "px";
              document.querySelector("#top-ad").appendChild(replica);
              animateIn(document.getElementById('current-ad'), ad_width, direction);

              var burnAfterReading = setTimeout(function () {
                if (current_ad.parentNode) {
                  current_ad.parentNode.removeChild(current_ad);
                }
              }, 400);

              generate(feed_items[productIndex]);
            }
          };

          // event listeners for navigation
          btnLeft.addEventListener('click', ScrollNav.left);
          btnRight.addEventListener('click', ScrollNav.right);

          if(document.getElementById('disclaimer-text').innerHTML != "") {
            document.getElementById('disclaimer-text').addEventListener('click', function(event) {
              event.stopPropagation();
              document.querySelector('.disclaimer').style.display = 'inline';

              document.getElementById('disclaimer-close').addEventListener('click', function(event) {
                event.stopPropagation();
                document.querySelector('.disclaimer').style.display = 'none';
              });
            });
          }
        }

        function generate(feedItem) {
          document.querySelector('#current-ad #item-image').style.background = sifi.shared.backgroundStyleWithFallback(feedItem);

          replaceFeedMacros(feedItem, ['headline', 'tagline', 'cta', 'item-price-s', 'item-price', 'item-subtitle', 'item-title']);
          sifi.shared.checkPrices(feed_items, productIndex);
        }

        var indexChanged = function(newCurrentProduct, newProductIndex) {
          currentProduct = newCurrentProduct;
          productIndex = newProductIndex;
        };

        function replaceFeedMacros (item, elementIds) {
          document.getElementById('item-price-s').innerHTML = adCopy.msrp;
          document.getElementById('item-price').innerHTML = adCopy.sale;
          document.getElementById('item-subtitle').innerHTML = adCopy.id;
          document.getElementById('item-title').innerHTML = adCopy.title;

          if(document.getElementById('headline')) {
            document.getElementById('headline').innerHTML = adCopy.headline;
          }

          if(document.getElementById('tagline')) {
            document.getElementById('tagline').innerHTML = adCopy.tagline;
          }

          if(document.getElementById('cta')) {
            document.getElementById('cta').innerHTML = adCopy.cta;
          }

          if(document.getElementById('item-description')) {
            document.getElementById('item-description').innerHTML = adCopy.description;
          }

          sifi.shared.replaceFeedMacros(item, elementIds, ad);
        }

        ad.onLoadedItems = function(items, count) {
          adCopy = {
            msrp:document.getElementById('item-price-s').innerHTML,
            sale:document.getElementById('item-price').innerHTML,
            id:document.getElementById('item-subtitle').innerHTML,
            title:document.getElementById('item-title').innerHTML
          }

          if(document.getElementById('headline')) {
            adCopy.headline = document.getElementById('headline').innerHTML;
          }

          if(document.getElementById('tagline')) {
            adCopy.tagline = document.getElementById('tagline').innerHTML;
          }

          if(document.getElementById('cta')) {
            adCopy.cta = document.getElementById('cta').innerHTML;
          }

          if(document.getElementById('item-description')) {
            adCopy.description = document.getElementById('item-description').innerHTML;
          }

          if (items.length > 0) {
            feed_items = items;
          }

          generate(feed_items[productIndex]);

          currentProduct = feed_items[productIndex];
          ad.selectProduct(currentProduct);
        };

        var adCopy;
        ad.initializeAd(sifiFeedInfo);
        initializeUi();
      };

      // Public API
      self.call = call;
      return self;
    }

    sifi.common = new Common(sifi);
    sifi.common.requires = ['shared'];
    return sifi.common;
  };
});
