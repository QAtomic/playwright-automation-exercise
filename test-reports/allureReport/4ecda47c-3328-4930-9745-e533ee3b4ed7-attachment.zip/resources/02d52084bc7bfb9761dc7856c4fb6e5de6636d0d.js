//////  INIT  ////////

function startAd() {
  hideElement(txt_1a);
  hideElement(txt_1b);
  hideElement(txt_2a);
  hideElement(txt_2b);
  hideElement(cta);
  hideElement(AI_Assistant);
  hideElement(List_Key_Items);
  hideElement(Limitation);
  hideElement(Compensation);
  hideElement(pages);

  TweenMax.set(".lgArt", { transformOrigin: "left top", scale: 0.5 });
  TweenMax.set(".screen", { transformOrigin: "left top", scale: 0.52 });
  TweenMax.set(".laptop", { x: 300 });
  TweenMax.delayedCall(0, intro);
}

//////  START ANIMATION  ////////

intro = function () {
  TweenMax.delayedCall(0, revealAd);
  TweenMax.delayedCall(0.5, step01);
  TweenMax.delayedCall(2, pages01);
  TweenMax.delayedCall(3.5, pages02);
  TweenMax.delayedCall(5, pages03);
  TweenMax.delayedCall(6.5, pages04);
  TweenMax.delayedCall(8, pages05);
  TweenMax.delayedCall(10, pages06);
  TweenMax.delayedCall(12, pages07);
};

revealAd = function () {
  TweenMax.to(cover, 0.5, { alpha: 0 });
};

step01 = function () {
  showElement(txt_1a);
  showElement(txt_1b);
  showElement(cta);
  showElement(AI_Assistant);
  showElement(pages);

  TweenMax.to(pages, 0.75, {
    x: 300,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.from(txt_1a, 0.7, {
    y: 12,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.from(txt_1b, 0.7, {
    y: 12,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.2,
  });
  TweenMax.from(cta, 0.5, {
    y: 12,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.4,
  });

  TweenMax.from(AI_Assistant, 0.3, {
    scale: 0.3,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.5,
  });
  TweenMax.to(AI_Assistant, 0.2, {
    scale: 0.5,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.8,
  });
};

pages01 = function () {
  //TweenMax.to(AI_Assistant, .1, {scale:.46, rotation:0.01, ease:Quad.easeOut, delay:.2})
  //TweenMax.to(AI_Assistant, .2, {scale:.5, rotation:0.01, ease:Quad.easeOut, delay:.3})

  TweenMax.to(page_1, 0.5, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_2, 0.5, {
    x: -12,
    y: -12,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_3, 0.5, {
    alpha: 1,
    x: -12,
    y: -12,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_4, 0.5, {
    alpha: 1,
    x: 13,
    y: 13,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.2,
  });
};

pages02 = function () {
  TweenMax.to(page_2, 0.5, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });

  TweenMax.to(page_3, 0.5, {
    x: -24,
    y: -24,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_4, 0.5, {
    alpha: 1,
    x: 1,
    y: 1,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_5, 0.5, {
    alpha: 1,
    x: 13,
    y: 13,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.2,
  });
};

pages03 = function () {
  TweenMax.to(page_3, 0.5, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });

  TweenMax.to(page_4, 0.5, {
    x: -11,
    y: -11,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_5, 0.5, {
    alpha: 1,
    x: 1,
    y: 1,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(page_6, 0.5, {
    alpha: 1,
    x: 13,
    y: 13,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.2,
  });
};

pages04 = function () {
  showElement(List_Key_Items);

  TweenMax.from(List_Key_Items, 0.3, {
    scale: 0.3,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(List_Key_Items, 0.2, {
    scale: 0.5,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.3,
  });
};

pages05 = function () {
  TweenMax.to(List_Key_Items, 0.1, {
    scale: 0.46,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(List_Key_Items, 0.2, {
    scale: 0.5,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.1,
  });
};

pages06 = function () {
  showElement(Compensation);
  showElement(txt_2a);
  showElement(txt_2b);

  TweenMax.to(List_Key_Items, 0.2, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });

  TweenMax.from(Compensation, 0.3, {
    scale: 0.3,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(Compensation, 0.2, {
    scale: 0.49,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.3,
  });
  TweenMax.to(".txt_1", 0.5, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.from(txt_2a, 0.75, {
    y: 12,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.from(txt_2b, 0.75, {
    y: 12,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.2,
  });
};

pages07 = function () {
  showElement(Limitation);

  TweenMax.to(Compensation, 0.2, {
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });

  TweenMax.from(Limitation, 0.3, {
    scale: 0.3,
    alpha: 0,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0,
  });
  TweenMax.to(Limitation, 0.2, {
    scale: 0.49,
    rotation: 0.01,
    ease: Quad.easeOut,
    delay: 0.3,
  });
};

showElement = function (e) {
  e.style.visibility = "visible";
};

hideElement = function (e) {
  e.style.visibility = "hidden";
};
