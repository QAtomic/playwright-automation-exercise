//////  INIT  ////////


function startAd() {
	hideElement(txt_1);
	hideElement(txt_2);
	hideElement(cta);
	hideElement(screen_1);
	hideElement(screen_2);
	hideElement(screen_3);
	hideElement(screen_4);
	hideElement(scan);
	hideElement(Combine_files);
	hideElement(Organize_pages);
	hideElement(w2);
	hideElement(phoneWrap);
	hideElement(layer_red);

	
	
	TweenMax.set(".lgArt",{transformOrigin: "left top", scale:1});
	TweenMax.set(".lap",{transformOrigin: "left top", scale:0.526});
	TweenMax.set(".phoneimg",{transformOrigin: "left top", scale:.5});
	TweenMax.set(".phoneWrap",{scale:.387});
	TweenMax.set(".tools",{scale:.16});
	TweenMax.set(".art",{scale:.5});
	TweenMax.set(".w2h",{scale:0.67});
	TweenMax.set(".laptop",{x:-800,scale:.43,y:-110});
	TweenMax.set(".screen_1",{scaleX:.43,scaleY:.39});
	TweenMax.set(".screen_2",{scaleX:.32,scaleY:.29});
	TweenMax.set(".screen_3",{scaleX:.28,scaleY:.25});
	TweenMax.set(".screen_4",{scale:.31});
	


	
  	TweenMax.delayedCall(0,intro);
}

//////  START ANIMATION  ////////

intro = function() {  
	TweenMax.delayedCall(0,revealAd);
	TweenMax.delayedCall(1,step01);
	TweenMax.delayedCall(4,step02);
	TweenMax.delayedCall(4.3,step03);
	TweenMax.delayedCall(7,step04);
}

revealAd = function() { 
	TweenMax.to(cover,.5,{alpha: 0});
}

step01 = function() {
	showElement(txt_1);
	showElement(scan);
	showElement(cta);
	showElement(w2);
	showElement(phoneWrap);
	
	TweenMax.from(w2, .4, {x:-300, alpha:0, rotation:0.01, ease: "power4.inOut", delay:0});
	TweenMax.from(".phone", .4, {x:-300, alpha:0, rotation:0.01, ease: "power4.inOut", delay:1});
	
	TweenMax.from(scan, .3, {scale:.33, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:1.4})
	TweenMax.to(scan, .2, {scale:.5, rotation:0.01, ease:Quad.easeOut, delay:1.7})
	TweenMax.from(txt_1, .5, {y:12, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:0});
	TweenMax.from(cta, .5, {y:12, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:.4});
	
    TweenMax.to(phoneWrap, .4, {x:-12, ease: "power4.inOut", delay:2.2});
	TweenMax.to(w2, .4, {x:-33, y:5, scale:0.235, rotation:0.01, ease: "power4.inOut", delay:2.2});
	TweenMax.to(scan, .3, {scale:.33, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:2.3})

	
}
step02 = function() {
	
	TweenMax.to(phoneWrap, .4, {x:-300, ease: "power4.inOut", delay:0});
}
step03 = function() {
	showElement(screen_1);
	showElement(screen_2);
	showElement(screen_3);
	showElement(screen_4);
	showElement(Combine_files);
	showElement(Organize_pages);
	showElement(txt_2);
	
	
	TweenMax.to(".laptop", .5, {x:-63,y:-113, rotation:0.01, ease:Quad.easeOut, delay:0});
	TweenMax.from(screen_1, .5, {x:-300, alpha:1, rotation:0.01, ease:Quad.easeOut, delay:.1});
	TweenMax.from(screen_2, .5, {x:-300, alpha:1, rotation:0.01, ease:Quad.easeOut, delay:.2});
	TweenMax.from(screen_3, .5, {x:-300, alpha:1, rotation:0.01, ease:Quad.easeOut, delay:.3});
	TweenMax.from(screen_4, .5, {x:-300, alpha:1, rotation:0.01, ease:Quad.easeOut, delay:.4});
	
	TweenMax.from(Combine_files, .3, {scale:.33, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:1})
	TweenMax.to(Combine_files, .2, {scale:.5, rotation:0.01, ease:Quad.easeOut, delay:1.3})
	TweenMax.from(Organize_pages, .3, {scale:.33, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:1});
	TweenMax.to(Organize_pages, .2, {scale:.5, rotation:0.01, ease:Quad.easeOut, delay:1.3});
	TweenMax.from(txt_2, .5, {y:12, alpha:0, rotation:0.01, ease:Quad.easeOut, delay:1.6});
	setTimeout(() => {
		showElement(layer_red);
		
	}, 500);

}
step04 = function() {
	
	TweenMax.to(line, .5, { rotation:0.01, ease:Quad.easeOut, opacity:0.5, delay:0});
	TweenMax.to(screen_1, .5, {x:155, y:133, scale:.155, rotation:0.01, ease:Quad.easeOut, delay:0});
	TweenMax.to(screen_2, .5, {x:-61, y:111,  scale:.27, rotation:0.01, ease:Quad.easeOut, delay:0});
	TweenMax.to(screen_3, .5, {x:-100, y:-99, scaleX:.165,scaleY:.18, rotation:0.01, ease:Quad.easeOut, delay:0});
	TweenMax.to(screen_4, .5, {x:-0, y:-185, scaleX:.27, scaleY:.27, rotation:0.01, ease:Quad.easeOut, delay:0});

	
}


showElement = function(e){
  e.style.visibility = 'visible';
}

hideElement = function(e){
  e.style.visibility = 'hidden';
}